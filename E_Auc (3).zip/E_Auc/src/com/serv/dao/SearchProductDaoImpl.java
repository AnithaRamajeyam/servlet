package com.serv.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.serv.beans.SearchProduct;
import com.serv.util.DBConstants;
import com.serv.util.DBUtil;

public class SearchProductDaoImpl implements SearchProductDao {


	public List<SearchProduct> getProductInfo(SearchProduct sp) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		List<SearchProduct> search=new ArrayList<SearchProduct>();
		try {
			
			conn = DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME,DBConstants.PWD);
			pst = conn.prepareStatement("select * from put_for_sales where Catagory =?");
			pst.setString(1, sp.getCategory());
			rs= pst.executeQuery();
			
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			String current=sf.format(new Date());
			while(rs.next())
			{
				String end=rs.getString(8);
				LocalDate startDate = LocalDate.parse(end); 
				LocalDate endDate = LocalDate.parse(current);
				Period period = Period.between(startDate, endDate); 
				search.add(new SearchProduct(rs.getString(3), rs.getString(4),period));
			}
			rs.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return search;
	}

}
