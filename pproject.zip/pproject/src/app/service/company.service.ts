import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export class Company {

  companyCode: number;
  companyName: String;
  turnOver: String;
  ceo: String;
  boardOfDirectors: String;
  stockCode: number;
  sectorId:number;
  briefWriteup: String;
}
@Injectable({
  providedIn: 'root'
})

export class CompanyService {

  constructor( private httpclient:HttpClient) { }

  insertCompany(company: Company): Observable<any> {
    return this.httpclient.post(`http://localhost:9090/insertcompany`, company);
  }

  getCompanylist(): Observable<any> {
    return this.httpclient.get<any>(`http://localhost:9090/companylist`);
  }
}
