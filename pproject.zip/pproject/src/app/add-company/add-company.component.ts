import { Component, OnInit } from '@angular/core';
import { CompanyService, Company } from 'src/app/service/company.service';

@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css']
})
export class AddCompanyComponent implements OnInit {

  constructor(private companyService: CompanyService) { }
  company: Company = new Company();
  ngOnInit() {
  }
  onSubmit() {
    console.log(this.company);
    this.companyService.insertCompany(this.company).subscribe(
      async res => {
        this.company = await res;
        console.log(this.company);
        alert("company added successfully.");
        //this.router.navigate(['admin/list-company']);
      },
      error => console.log(error)
    );
  }
}
