package com.demo.stockExchangeApplication.controller;

import java.sql.SQLException;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import com.demo.stockExchangeApplication.model.Company;

public interface CompanyController {
	public Company insertCompany(Company company) throws SQLException;
	public ModelAndView getCompanyList() throws Exception;

}
