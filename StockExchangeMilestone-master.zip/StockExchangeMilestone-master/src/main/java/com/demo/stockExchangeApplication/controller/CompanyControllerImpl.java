package com.demo.stockExchangeApplication.controller;

import java.sql.SQLException;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.demo.stockExchangeApplication.model.Company;
import com.demo.stockExchangeApplication.service.CompanyService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CompanyControllerImpl implements CompanyController{
	
	@Autowired
	CompanyService companyservice;
	
//	@RequestMapping("/insertcompany")
//	public String Load(Model model)
//	{
//		Company company=new Company();
//		model.addAttribute("company", company);
//		return "insertCompany";
//	}
	@PostMapping(value="/insertcompany")
	public Company insertCompany(@RequestBody Company company) throws SQLException
	{
		System.out.println("Creating Company");
		Company companyob = companyservice.insertCompany(company);
		return  companyob;
	}
	@GetMapping(path = "/companylist")
	public List<Company> getCompanies() throws Exception {
		System.out.println("Get all Companies...");
		return companyservice.getCompanyList();
	}
//    public String insertCompany( @Valid Company company,BindingResult result,Model model) throws SQLException{
//		 if (result.hasErrors()) {
//	            return "insertCompany";
//	      }
//		 else
//		 {
//			 Company result1=service.insertCompany(company);
//			 if(result1!=null)
//			 {
//				 	return "redirect:displaycompany";
//			 }
//			 else
//			 {
//				 	return "error";
//			 }
//		 }
//	}

	@Override
	public ModelAndView getCompanyList() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
//	@RequestMapping("/displaycompany")
//	public ModelAndView getCompanyList() throws Exception {
//		ModelAndView mv=new ModelAndView();
//		mv.setViewName("displayCompany");
//		mv.addObject("companyList",companyservice.getCompanyList());
//		return mv;
//	}
//	@RequestMapping("/updatecompany")
//	public ModelAndView updatecompany(@RequestParam("id") int id,Model model)
//	{
//		ModelAndView mv=new ModelAndView();
//		System.out.println(id);
//		Company company=new Company();
//		model.addAttribute("company", company);
//		mv.setViewName("updatecompany");
//		mv.addObject("companyList",companyservice.getUpdateCompanyList(id));
//		return mv;
//	}
//	@Override
//	public String insertCompany(Company company, BindingResult result, Model model) throws SQLException {
//		// TODO Auto-generated method stub
//		return null;
//	}
}
